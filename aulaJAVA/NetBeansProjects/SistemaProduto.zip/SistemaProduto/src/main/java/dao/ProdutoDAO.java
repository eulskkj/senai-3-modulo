package dao;

import java.util.ArrayList;
import java.util.List;
import model.Produto;

public class ProdutoDAO {
    private static List<Produto> lista = new ArrayList<>();

    public void salvar(Produto p) {
        lista.add(p);
    }

    public List<Produto> listar() {
        return lista;
    }

    public void remover(int id) {
        lista.removeIf(p -> p.getId() == id);
    }
}