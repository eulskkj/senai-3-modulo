package dao;

import java.util.ArrayList;
import java.util.List;
import model.Usuario;

public class UsuarioDAO {
    private static List<Usuario> usuarios = new ArrayList<>();

    static {
        usuarios.add(new Usuario("admin", "123"));
    }

    public boolean validar(String login, String senha) {
        for (Usuario u : usuarios) {
            if (u.getLogin().equals(login) && u.getSenha().equals(senha)) {
                return true;
            }
        }
        return false;
    }
}