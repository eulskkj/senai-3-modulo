package sistemaprodutosmvc;

import view.TelaLogin;

public class SistemaProdutosMVC {
    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> {
            new TelaLogin().setVisible(true);
        });
    }
}