package controller;

import dao.UsuarioDAO;

public class LoginController {
    public boolean validarLogin(String usuario, String senha) {
        UsuarioDAO dao = new UsuarioDAO();
        return dao.validar(usuario, senha);
    }
}
