package controller;

import dao.ProdutoDAO;
import model.Produto;
import java.util.List;

public class ProdutoController {
    private ProdutoDAO dao = new ProdutoDAO();

    public void cadastrar(int id, String nome, String cat, double preco, int qtd) {
        dao.salvar(new Produto(id, nome, cat, preco, qtd));
    }

    public List<Produto> listar() {
        return dao.listar();
    }

    public void excluir(int id) {
        dao.remover(id);
    }
}