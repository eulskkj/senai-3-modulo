package view;

import controller.LoginController;
import javax.swing.*;
import java.awt.*;

public class TelaLogin extends JFrame {
    // Componentes da interface
    private JTextField txtUsuario = new JTextField(15);
    private JPasswordField txtSenha = new JPasswordField(15);
    private JButton btnEntrar = new JButton("Entrar");

    public TelaLogin() {
        // Configurações básicas da janela
        setTitle("Login do Sistema");
        setSize(350, 200);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centraliza na tela
        setLayout(new BorderLayout(10, 10));

        // Painel central para os campos (Usando GridLayout para alinhar)
        JPanel pnlCampos = new JPanel(new GridLayout(2, 2, 5, 10));
        pnlCampos.setBorder(BorderFactory.createEmptyBorder(20, 20, 10, 20));
        
        pnlCampos.add(new JLabel("Usuário:"));
        pnlCampos.add(txtUsuario);
        pnlCampos.add(new JLabel("Senha:"));
        pnlCampos.add(txtSenha);
        
        add(pnlCampos, BorderLayout.CENTER);

        // Painel inferior para o botão
        JPanel pnlBotao = new JPanel();
        pnlBotao.add(btnEntrar);
        add(pnlBotao, BorderLayout.SOUTH);

        // --- LÓGICA DO BOTÃO ENTRAR ---
        btnEntrar.addActionListener(e -> {
            String usuario = txtUsuario.getText();
            String senha = new String(txtSenha.getPassword());

            LoginController control = new LoginController();
            
            // Verifica se o login é válido usando o Controller
            if (control.validarLogin(usuario, senha)) {
                // Se estiver correto, abre a Tela de Produtos e fecha esta
                new TelaProduto().setVisible(true);
                this.dispose();
            } else {
                // Se estiver errado, mostra mensagem de erro
                JOptionPane.showMessageDialog(this, 
                    "Usuário ou Senha incorretos!", 
                    "Erro de Acesso", 
                    JOptionPane.ERROR_MESSAGE);
                
                txtUsuario.setText("");
                txtSenha.setText("");
                txtUsuario.requestFocus();
            }
        });
    }
}