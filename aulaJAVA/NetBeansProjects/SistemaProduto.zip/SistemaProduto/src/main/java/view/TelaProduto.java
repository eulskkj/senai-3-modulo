package view;

import controller.ProdutoController;
import model.Produto;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class TelaProduto extends JFrame {
    // Campos de texto
    private JTextField txtId = new JTextField(5), txtNome = new JTextField(10), 
                       txtCat = new JTextField(10), txtPreco = new JTextField(5), 
                       txtQtd = new JTextField(5);
    
    // Botões
    private JButton btnSalvar = new JButton("Salvar"), 
                    btnListar = new JButton("Listar"), 
                    btnExcluir = new JButton("Excluir"),
                    btnPesquisar = new JButton("Pesquisar");
    
    // Tabela
    private JTable tabela = new JTable();
    private DefaultTableModel modelo = new DefaultTableModel();

    public TelaProduto() {
        // Configurações da Janela
        setTitle("Sistema de Cadastro de Produtos");
        setSize(750, 450);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        // PAINEL SUPERIOR (Formulário)
        JPanel pnlForm = new JPanel(new GridLayout(3, 4, 10, 10));
        pnlForm.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        pnlForm.add(new JLabel("ID:")); pnlForm.add(txtId);
        pnlForm.add(new JLabel("Nome:")); pnlForm.add(txtNome);
        pnlForm.add(new JLabel("Categoria:")); pnlForm.add(txtCat);
        pnlForm.add(new JLabel("Preço:")); pnlForm.add(txtPreco);
        pnlForm.add(new JLabel("Estoque:")); pnlForm.add(txtQtd);
        
        // Adicionando botões ao formulário
        pnlForm.add(btnSalvar);
        pnlForm.add(btnListar);
        add(pnlForm, BorderLayout.NORTH);

        // PAINEL CENTRAL (Tabela)
        modelo.setColumnIdentifiers(new Object[]{"ID", "Nome", "Categoria", "Preço", "Qtd"});
        tabela.setModel(modelo);
        add(new JScrollPane(tabela), BorderLayout.CENTER);

        // PAINEL INFERIOR (Ações extras)
        JPanel pnlBaixo = new JPanel();
        pnlBaixo.add(btnExcluir);
        pnlBaixo.add(btnPesquisar);
        add(pnlBaixo, BorderLayout.SOUTH);

        // --- LÓGICA DOS BOTÕES ---

        // SALVAR
        btnSalvar.addActionListener(e -> {
            try {
                ProdutoController pc = new ProdutoController();
                pc.cadastrar(
                    Integer.parseInt(txtId.getText()), 
                    txtNome.getText(), 
                    txtCat.getText(), 
                    Double.parseDouble(txtPreco.getText()), 
                    Integer.parseInt(txtQtd.getText())
                );
                JOptionPane.showMessageDialog(this, "Produto salvo com sucesso!");
                limparCampos();
                btnListar.doClick(); // Atualiza a tabela
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Erro: Preencha os campos corretamente!");
            }
        });

        // LISTAR
        btnListar.addActionListener(e -> {
            modelo.setRowCount(0); // Limpa a tabela
            ProdutoController pc = new ProdutoController();
            List<Produto> lista = pc.listar();
            for (Produto p : lista) {
                modelo.addRow(new Object[]{
                    p.getId(), p.getNome(), p.getCategoria(), p.getPreco(), p.getQuantidade()
                });
            }
        });

        // EXCLUIR
        btnExcluir.addActionListener(e -> {
            int linha = tabela.getSelectedRow();
            if (linha != -1) {
                int id = (int) modelo.getValueAt(linha, 0);
                new ProdutoController().excluir(id);
                JOptionPane.showMessageDialog(this, "Removido!");
                btnListar.doClick();
            } else {
                JOptionPane.showMessageDialog(this, "Selecione uma linha na tabela!");
            }
        });

        // PESQUISAR
        btnPesquisar.addActionListener(e -> {
            String busca = JOptionPane.showInputDialog("Nome do produto para pesquisar:");
            if (busca != null && !busca.isEmpty()) {
                modelo.setRowCount(0);
                ProdutoController pc = new ProdutoController();
                for (Produto p : pc.listar()) {
                    if (p.getNome().toLowerCase().contains(busca.toLowerCase())) {
                        modelo.addRow(new Object[]{p.getId(), p.getNome(), p.getCategoria(), p.getPreco(), p.getQuantidade()});
                    }
                }
            }
        });
    }

    private void limparCampos() {
        txtId.setText(""); txtNome.setText(""); txtCat.setText(""); 
        txtPreco.setText(""); txtQtd.setText("");
        txtId.requestFocus();
    }
}