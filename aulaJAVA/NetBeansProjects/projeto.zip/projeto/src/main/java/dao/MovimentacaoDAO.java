package dao;

import model.Movimentacao;
import model.Movimentacao.Tipo;
import util.ConexaoDB;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MovimentacaoDAO {

    public boolean registrar(Movimentacao m) {
        Connection con = ConexaoDB.getConexao();
        try {
            con.setAutoCommit(false);

            // 1. Busca quantidade atual
            int qtdAtual = 0;
            PreparedStatement sel = con.prepareStatement("SELECT quantidade FROM produtos WHERE id = ?");
            sel.setInt(1, m.getProdutoId());
            ResultSet rs = sel.executeQuery();
            if (rs.next()) qtdAtual = rs.getInt(1);
            sel.close();

            // 2. Valida saída
            if (m.getTipo() == Tipo.SAIDA && qtdAtual < m.getQuantidade()) {
                con.rollback();
                return false;  // estoque insuficiente
            }

            // 3. Atualiza estoque
            int novaQtd = m.getTipo() == Tipo.ENTRADA
                ? qtdAtual + m.getQuantidade()
                : qtdAtual - m.getQuantidade();
            PreparedStatement upd = con.prepareStatement("UPDATE produtos SET quantidade = ? WHERE id = ?");
            upd.setInt(1, novaQtd);
            upd.setInt(2, m.getProdutoId());
            upd.executeUpdate();
            upd.close();

            // 4. Registra movimentação
            PreparedStatement ins = con.prepareStatement(
                "INSERT INTO movimentacoes (produto_id, usuario_id, tipo, quantidade, observacao) VALUES (?,?,?,?,?)",
                Statement.RETURN_GENERATED_KEYS);
            ins.setInt(1, m.getProdutoId());
            ins.setInt(2, m.getUsuarioId());
            ins.setString(3, m.getTipo().name());
            ins.setInt(4, m.getQuantidade());
            ins.setString(5, m.getObservacao());
            ins.executeUpdate();
            ResultSet ks = ins.getGeneratedKeys();
            if (ks.next()) m.setId(ks.getInt(1));
            ins.close();

            con.commit();
            return true;

        } catch (SQLException e) {
            try { con.rollback(); } catch (SQLException ex) { ex.printStackTrace(); }
            e.printStackTrace();
        } finally {
            try { con.setAutoCommit(true); } catch (SQLException e) { e.printStackTrace(); }
        }
        return false;
    }

    public List<Movimentacao> listarPorProduto(int produtoId) {
        List<Movimentacao> lista = new ArrayList<>();
        String sql =
            "SELECT m.id, m.produto_id, p.nome AS produto_nome, " +
            "       m.usuario_id, u.login AS usuario_login, " +
            "       m.tipo, m.quantidade, m.observacao, m.data " +
            "FROM movimentacoes m " +
            "JOIN produtos p ON p.id = m.produto_id " +
            "JOIN usuarios u ON u.id = m.usuario_id " +
            "WHERE m.produto_id = ? ORDER BY m.data DESC";
        try (Connection con = ConexaoDB.getConexao();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, produtoId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) lista.add(mapear(rs));
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    public List<Movimentacao> listarTodas() {
        List<Movimentacao> lista = new ArrayList<>();
        String sql =
            "SELECT m.id, m.produto_id, p.nome AS produto_nome, " +
            "       m.usuario_id, u.login AS usuario_login, " +
            "       m.tipo, m.quantidade, m.observacao, m.data " +
            "FROM movimentacoes m " +
            "JOIN produtos p ON p.id = m.produto_id " +
            "JOIN usuarios u ON u.id = m.usuario_id " +
            "ORDER BY m.data DESC";
        try (Connection con = ConexaoDB.getConexao();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) lista.add(mapear(rs));
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    private Movimentacao mapear(ResultSet rs) throws SQLException {
        Movimentacao m = new Movimentacao();
        m.setId(rs.getInt("id"));
        m.setProdutoId(rs.getInt("produto_id"));
        m.setProdutoNome(rs.getString("produto_nome"));
        m.setUsuarioId(rs.getInt("usuario_id"));
        m.setUsuarioLogin(rs.getString("usuario_login"));
        m.setTipo(Tipo.valueOf(rs.getString("tipo")));
        m.setQuantidade(rs.getInt("quantidade"));
        m.setObservacao(rs.getString("observacao"));
        m.setData(rs.getTimestamp("data"));
        return m;
    }
}
