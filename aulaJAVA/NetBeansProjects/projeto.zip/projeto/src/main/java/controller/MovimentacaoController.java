package controller;

import dao.MovimentacaoDAO;
import model.Movimentacao;
import model.Movimentacao.Tipo;
import model.Usuario;

import java.util.List;

public class MovimentacaoController {

    private final MovimentacaoDAO dao = new MovimentacaoDAO();

    public boolean registrar(int produtoId, String tipoStr, String qtdStr, String obs) {
        Usuario u = UsuarioController.getUsuarioLogado();
        if (u == null) throw new IllegalStateException("Usuário não autenticado.");

        if (qtdStr == null || qtdStr.trim().isEmpty())
            throw new IllegalArgumentException("Informe a quantidade.");

        int qtd;
        try {
            qtd = Integer.parseInt(qtdStr.trim());
            if (qtd <= 0) throw new IllegalArgumentException("Quantidade deve ser maior que zero.");
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Quantidade inválida.");
        }

        Tipo tipo;
        try { tipo = Tipo.valueOf(tipoStr.toUpperCase()); }
        catch (Exception e) { throw new IllegalArgumentException("Tipo inválido: use ENTRADA ou SAIDA."); }

        Movimentacao m = new Movimentacao(produtoId, u.getId(), tipo, qtd, obs);
        return dao.registrar(m);
    }

    public List<Movimentacao> listarPorProduto(int produtoId) {
        return dao.listarPorProduto(produtoId);
    }

    public List<Movimentacao> listarTodas() {
        return dao.listarTodas();
    }
}
