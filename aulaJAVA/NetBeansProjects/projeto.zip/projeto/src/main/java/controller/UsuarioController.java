package controller;

import dao.UsuarioDAO;
import model.Usuario;

public class UsuarioController {

    private final UsuarioDAO dao = new UsuarioDAO();
    private static Usuario usuarioLogado = null;

    public boolean login(String login, String senha) {
        if (login == null || login.trim().isEmpty() ||
            senha == null || senha.trim().isEmpty()) return false;

        Usuario u = dao.autenticar(login.trim(), senha);
        if (u != null) {
            usuarioLogado = u;
            return true;
        }
        return false;
    }

    public boolean cadastrar(String login, String senha, String confirmaSenha) {
        if (login == null || login.trim().isEmpty())  return false;
        if (senha == null || senha.length() < 4)      return false;
        if (!senha.equals(confirmaSenha))             return false;
        if (dao.loginExiste(login.trim()))             return false;

        return dao.cadastrar(new Usuario(login.trim(), senha));
    }

    public void logout() {
        usuarioLogado = null;
    }

    public static Usuario getUsuarioLogado() {
        return usuarioLogado;
    }

    public boolean isLogado() {
        return usuarioLogado != null;
    }
}
