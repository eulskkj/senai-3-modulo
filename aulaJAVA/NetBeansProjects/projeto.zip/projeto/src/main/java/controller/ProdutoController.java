package controller;

import dao.ProdutoDAO;
import model.Produto;
import model.Usuario;

import java.math.BigDecimal;
import java.util.List;

public class ProdutoController {

    private final ProdutoDAO dao = new ProdutoDAO();

    public boolean cadastrar(String nome, String qtdStr, String precoStr, int categoriaId) {
        Usuario u = UsuarioController.getUsuarioLogado();
        if (u == null) return false;

        String err = validar(nome, qtdStr, precoStr);
        if (err != null) throw new IllegalArgumentException(err);

        Produto p = new Produto(
            nome.trim(),
            Integer.parseInt(qtdStr.trim()),
            new BigDecimal(precoStr.trim().replace(",", ".")),
            u.getId(),
            categoriaId
        );
        return dao.inserir(p);
    }

    public boolean atualizar(int id, String nome, String qtdStr, String precoStr, int categoriaId) {
        String err = validar(nome, qtdStr, precoStr);
        if (err != null) throw new IllegalArgumentException(err);

        Produto p = new Produto(
            nome.trim(),
            Integer.parseInt(qtdStr.trim()),
            new BigDecimal(precoStr.trim().replace(",", ".")),
            0,      // não altera o dono
            categoriaId
        );
        p.setId(id);
        return dao.atualizar(p);
    }

    public boolean remover(int id) {
        return dao.remover(id);
    }

    public List<Produto> listar() {
        return dao.listar();
    }

    public List<Produto> buscar(String nome) {
        if (nome == null || nome.trim().isEmpty()) return dao.listar();
        return dao.buscarPorNome(nome.trim());
    }

    public Produto buscarPorId(int id) {
        return dao.buscarPorId(id);
    }

    // Retorna mensagem de erro ou null se tudo ok
    private String validar(String nome, String qtdStr, String precoStr) {
        if (nome == null || nome.trim().isEmpty())
            return "Nome do produto é obrigatório.";
        try {
            int q = Integer.parseInt(qtdStr.trim());
            if (q < 0) return "Quantidade não pode ser negativa.";
        } catch (NumberFormatException e) {
            return "Quantidade inválida.";
        }
        try {
            BigDecimal p = new BigDecimal(precoStr.trim().replace(",", "."));
            if (p.compareTo(BigDecimal.ZERO) < 0) return "Preço não pode ser negativo.";
        } catch (NumberFormatException e) {
            return "Preço inválido.";
        }
        return null;
    }
}
