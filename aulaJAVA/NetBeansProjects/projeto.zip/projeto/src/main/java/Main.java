import view.TelaLogin;
import javax.swing.*;

/**
 * Ponto de entrada da aplicação.
 * Executa na Event Dispatch Thread (EDT) conforme boas práticas Swing.
 */
public class Main {
    public static void main(String[] args) {
        // Tenta usar o look-and-feel do sistema operacional
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            // mantém o padrão Metal se falhar
        }

        SwingUtilities.invokeLater(() -> {
            new TelaLogin().setVisible(true);
        });
    }
}
