package view;

import controller.ProdutoController;
import dao.CategoriaDAO;
import model.Categoria;
import model.Produto;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.math.BigDecimal;
import java.util.List;

public class TelaCadastroProduto extends JDialog {

    private JTextField txtNome;
    private JTextField txtQuantidade;
    private JTextField txtPreco;
    private JComboBox<Categoria> cbCategoria;

    private final ProdutoController ctrl = new ProdutoController();
    private Produto produtoEdicao = null;   // null = modo cadastro
    private boolean salvo = false;

    /** Construtor para CADASTRO de novo produto */
    public TelaCadastroProduto(Frame pai) {
        super(pai, "Cadastrar Produto", true);
        inicializar();
    }

    /** Construtor para EDIÇÃO de produto existente */
    public TelaCadastroProduto(Frame pai, Produto produto) {
        super(pai, "Editar Produto", true);
        this.produtoEdicao = produto;
        inicializar();
        preencherCampos();
    }

    private void inicializar() {
        setSize(430, 320);
        setLocationRelativeTo(getOwner());
        setResizable(false);
        construirUI();
    }

    private void construirUI() {
        JPanel painel = new JPanel(new GridBagLayout());
        painel.setBorder(new EmptyBorder(20, 28, 20, 28));
        painel.setBackground(Color.WHITE);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(6, 4, 6, 4);

        // Título
        String tituloTxt = (produtoEdicao == null) ? "Novo Produto" : "Editar Produto";
        JLabel titulo = new JLabel(tituloTxt, SwingConstants.CENTER);
        titulo.setFont(new Font("SansSerif", Font.BOLD, 17));
        titulo.setForeground(new Color(33, 89, 160));
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        painel.add(titulo, gbc);

        gbc.gridwidth = 1;

        // Nome
        gbc.gridy = 1; gbc.gridx = 0; gbc.weightx = 0.35;
        painel.add(new JLabel("Nome:"), gbc);
        txtNome = new JTextField(18);
        gbc.gridx = 1; gbc.weightx = 0.65;
        painel.add(txtNome, gbc);

        // Quantidade
        gbc.gridy = 2; gbc.gridx = 0; gbc.weightx = 0.35;
        painel.add(new JLabel("Quantidade:"), gbc);
        txtQuantidade = new JTextField(18);
        gbc.gridx = 1; gbc.weightx = 0.65;
        painel.add(txtQuantidade, gbc);

        // Preço
        gbc.gridy = 3; gbc.gridx = 0; gbc.weightx = 0.35;
        painel.add(new JLabel("Preço (R$):"), gbc);
        txtPreco = new JTextField(18);
        gbc.gridx = 1; gbc.weightx = 0.65;
        painel.add(txtPreco, gbc);

        // Categoria
        gbc.gridy = 4; gbc.gridx = 0; gbc.weightx = 0.35;
        painel.add(new JLabel("Categoria:"), gbc);
        cbCategoria = new JComboBox<>();
        carregarCategorias();
        gbc.gridx = 1; gbc.weightx = 0.65;
        painel.add(cbCategoria, gbc);

        // Botões
        JPanel pBotoes = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 0));
        pBotoes.setBackground(Color.WHITE);

        JButton btnSalvar = new JButton("Salvar");
        btnSalvar.setBackground(new Color(33, 130, 80));
        btnSalvar.setForeground(Color.WHITE);
        btnSalvar.setFont(new Font("SansSerif", Font.BOLD, 13));
        btnSalvar.setFocusPainted(false);
        btnSalvar.setBorderPainted(false);
        btnSalvar.setOpaque(true);
        btnSalvar.setPreferredSize(new Dimension(110, 32));

        JButton btnCancelar = new JButton("Cancelar");
        btnCancelar.setBackground(new Color(100, 100, 100));
        btnCancelar.setForeground(Color.WHITE);
        btnCancelar.setFont(new Font("SansSerif", Font.BOLD, 13));
        btnCancelar.setFocusPainted(false);
        btnCancelar.setBorderPainted(false);
        btnCancelar.setOpaque(true);
        btnCancelar.setPreferredSize(new Dimension(110, 32));

        pBotoes.add(btnCancelar);
        pBotoes.add(btnSalvar);

        gbc.gridy = 5; gbc.gridx = 0; gbc.gridwidth = 2;
        painel.add(pBotoes, gbc);

        add(painel);

        btnSalvar.addActionListener(e -> salvar());
        btnCancelar.addActionListener(e -> dispose());
    }

    private void carregarCategorias() {
        List<Categoria> cats = new CategoriaDAO().listar();
        cbCategoria.removeAllItems();
        for (Categoria c : cats) cbCategoria.addItem(c);
    }

    private void preencherCampos() {
        if (produtoEdicao == null) return;
        txtNome.setText(produtoEdicao.getNome());
        txtQuantidade.setText(String.valueOf(produtoEdicao.getQuantidade()));
        txtPreco.setText(produtoEdicao.getPreco().toPlainString());
        // Seleciona categoria correta no combo
        for (int i = 0; i < cbCategoria.getItemCount(); i++) {
            if (cbCategoria.getItemAt(i).getId() == produtoEdicao.getCategoriaId()) {
                cbCategoria.setSelectedIndex(i);
                break;
            }
        }
    }

    private void salvar() {
        Categoria catSel = (Categoria) cbCategoria.getSelectedItem();
        if (catSel == null) {
            JOptionPane.showMessageDialog(this, "Selecione uma categoria.", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            boolean ok;
            if (produtoEdicao == null) {
                ok = ctrl.cadastrar(txtNome.getText(), txtQuantidade.getText(), txtPreco.getText(), catSel.getId());
            } else {
                ok = ctrl.atualizar(produtoEdicao.getId(), txtNome.getText(), txtQuantidade.getText(), txtPreco.getText(), catSel.getId());
            }

            if (ok) {
                salvo = true;
                JOptionPane.showMessageDialog(this, "Produto salvo com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Erro ao salvar produto.", "Erro", JOptionPane.ERROR_MESSAGE);
            }
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Erro de Validação", JOptionPane.ERROR_MESSAGE);
        }
    }

    public boolean isSalvo() { return salvo; }
}