package view;

import controller.ProdutoController;
import controller.UsuarioController;
import model.Produto;
import model.Usuario;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

public class TelaPrincipal extends JFrame {

    // --- Tabela de produtos ---
    private JTable tabela;
    private DefaultTableModel modeloTabela;
    private JTextField txtBusca;

    private final ProdutoController ctrlProduto   = new ProdutoController();
    private final UsuarioController ctrlUsuario   = new UsuarioController();

    public TelaPrincipal() {
        setTitle("Sistema de Controle de Estoque");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(860, 580);
        setLocationRelativeTo(null);
        construirUI();
        carregarProdutos();
    }

    // ==========================================================
    // Construção da Interface
    // ==========================================================
    private void construirUI() {
        // ---- Barra superior ----
        JPanel barraTop = new JPanel(new BorderLayout());
        barraTop.setBackground(new Color(33, 89, 160));
        barraTop.setBorder(new EmptyBorder(10, 16, 10, 16));

        JLabel lblSistema = new JLabel("Controle de Estoque");
        lblSistema.setFont(new Font("SansSerif", Font.BOLD, 16));
        lblSistema.setForeground(Color.WHITE);

        Usuario u = UsuarioController.getUsuarioLogado();
        JLabel lblUsuario = new JLabel("Usuário: " + (u != null ? u.getLogin() : ""));
        lblUsuario.setFont(new Font("SansSerif", Font.PLAIN, 13));
        lblUsuario.setForeground(new Color(200, 220, 255));

        JButton btnLogout = new JButton("Sair");
        btnLogout.setFont(new Font("SansSerif", Font.BOLD, 12));
        btnLogout.setForeground(new Color(33, 89, 160));
        btnLogout.setBackground(Color.WHITE);
        btnLogout.setFocusPainted(false);
        btnLogout.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        JPanel pDireita = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 0));
        pDireita.setOpaque(false);
        pDireita.add(lblUsuario);
        pDireita.add(btnLogout);

        barraTop.add(lblSistema, BorderLayout.WEST);
        barraTop.add(pDireita, BorderLayout.EAST);

        add(barraTop, BorderLayout.NORTH);

        // ---- Painel central (abas) ----
        JTabbedPane abas = new JTabbedPane();
        abas.setFont(new Font("SansSerif", Font.PLAIN, 13));
        abas.addTab("📦  Produtos", criarAbaProdutos());
        abas.addTab("📊  Movimentações", criarAbaMovimentacoes());
        add(abas, BorderLayout.CENTER);

        // ---- Rodapé ----
        JPanel rodape = new JPanel(new FlowLayout(FlowLayout.LEFT));
        rodape.setBackground(new Color(245, 247, 250));
        rodape.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, new Color(210, 215, 225)));
        JLabel lblRodape = new JLabel("Sistema de Controle de Estoque  |  MVC + DAO  |  Java Swing + MySQL");
        lblRodape.setFont(new Font("SansSerif", Font.ITALIC, 11));
        lblRodape.setForeground(Color.GRAY);
        rodape.add(lblRodape);
        add(rodape, BorderLayout.SOUTH);

        // --- Ação Logout ---
        btnLogout.addActionListener(e -> {
            int resp = JOptionPane.showConfirmDialog(this,
                "Deseja realmente sair do sistema?", "Confirmar Saída",
                JOptionPane.YES_NO_OPTION);
            if (resp == JOptionPane.YES_OPTION) {
                ctrlUsuario.logout();
                new TelaLogin().setVisible(true);
                dispose();
            }
        });
    }

    // ==========================================================
    // Aba de Produtos
    // ==========================================================
    private JPanel criarAbaProdutos() {
        JPanel painel = new JPanel(new BorderLayout(6, 6));
        painel.setBorder(new EmptyBorder(10, 12, 10, 12));
        painel.setBackground(Color.WHITE);

        // --- Barra de ferramentas ---
        JPanel pFerr = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        pFerr.setBackground(Color.WHITE);

        JButton btnNovo      = botao("+ Novo Produto",  new Color(33, 130, 80));
        JButton btnEditar    = botao("✎ Editar",        new Color(33, 89, 160));
        JButton btnRemover   = botao("✕ Remover",       new Color(190, 50, 50));
        JButton btnMovimento = botao("⇄ Movimentação",  new Color(120, 80, 180));
        JButton btnAtualizar = botao("↻ Atualizar",     new Color(100, 110, 120));

        txtBusca = new JTextField(18);
        txtBusca.setToolTipText("Buscar produto pelo nome...");
        JButton btnBuscar = botao("Buscar", new Color(60, 130, 160));

        pFerr.add(btnNovo);
        pFerr.add(btnEditar);
        pFerr.add(btnRemover);
        pFerr.add(btnMovimento);
        pFerr.add(Box.createHorizontalStrut(20));
        pFerr.add(new JLabel("Busca:"));
        pFerr.add(txtBusca);
        pFerr.add(btnBuscar);
        pFerr.add(btnAtualizar);

        painel.add(pFerr, BorderLayout.NORTH);

        // --- Tabela ---
        String[] colunas = {"ID", "Nome", "Categoria", "Qtd.", "Preço (R$)", "Responsável", "Cadastrado em"};
        modeloTabela = new DefaultTableModel(colunas, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
            @Override public Class<?> getColumnClass(int col) {
                if (col == 0 || col == 3) return Integer.class;
                return String.class;
            }
        };
        tabela = new JTable(modeloTabela);
        tabela.setRowHeight(26);
        tabela.setFont(new Font("SansSerif", Font.PLAIN, 13));
        tabela.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 13));
        tabela.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabela.setGridColor(new Color(230, 235, 240));
        tabela.setShowVerticalLines(false);
        ((javax.swing.table.DefaultTableCellRenderer) tabela.getTableHeader().getDefaultRenderer()).setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        // Larguras das colunas
        int[] larguras = {40, 200, 120, 55, 100, 110, 150};
        for (int i = 0; i < larguras.length; i++)
            tabela.getColumnModel().getColumn(i).setPreferredWidth(larguras[i]);

        // Zebrar linhas
        tabela.setDefaultRenderer(Object.class, new javax.swing.table.DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object val, boolean sel, boolean foc, int row, int col) {
                Component c = super.getTableCellRendererComponent(t, val, sel, foc, row, col);
                if (!sel) c.setBackground(row % 2 == 0 ? Color.WHITE : new Color(245, 248, 252));
                ((javax.swing.JLabel) c).setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                return c;
            }
        });

        painel.add(new JScrollPane(tabela), BorderLayout.CENTER);

        // --- Ações dos botões ---
        btnNovo.addActionListener(e -> abrirCadastro());
        btnEditar.addActionListener(e -> abrirEdicao());
        btnRemover.addActionListener(e -> removerProduto());
        btnMovimento.addActionListener(e -> abrirMovimentacao());
        btnAtualizar.addActionListener(e -> carregarProdutos());
        btnBuscar.addActionListener(e -> buscarProdutos());
        txtBusca.addActionListener(e -> buscarProdutos());

        // Duplo clique na linha abre edição
        tabela.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) abrirEdicao();
            }
        });

        return painel;
    }

    // ==========================================================
    // Aba de Movimentações (histórico geral)
    // ==========================================================
    private JPanel criarAbaMovimentacoes() {
        JPanel painel = new JPanel(new BorderLayout(6, 6));
        painel.setBorder(new EmptyBorder(10, 12, 10, 12));
        painel.setBackground(Color.WHITE);

        String[] cols = {"ID", "Produto", "Tipo", "Qtd.", "Usuário", "Observação", "Data"};
        DefaultTableModel modeloMov = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable tabelaMov = new JTable(modeloMov);
        tabelaMov.setRowHeight(24);
        tabelaMov.setFont(new Font("SansSerif", Font.PLAIN, 12));
        tabelaMov.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 12));
        tabelaMov.setGridColor(new Color(230, 235, 240));
        tabelaMov.setShowVerticalLines(false);
        tabelaMov.getColumnModel().getColumn(0).setPreferredWidth(35);
        tabelaMov.getColumnModel().getColumn(1).setPreferredWidth(110);
        tabelaMov.getColumnModel().getColumn(2).setPreferredWidth(70);
        tabelaMov.getColumnModel().getColumn(3).setPreferredWidth(40);
        tabelaMov.getColumnModel().getColumn(4).setPreferredWidth(80);
        tabelaMov.getColumnModel().getColumn(5).setPreferredWidth(270);
        tabelaMov.getColumnModel().getColumn(6).setPreferredWidth(140);

        JScrollPane scroll = new JScrollPane(tabelaMov);
        painel.add(scroll, BorderLayout.CENTER);

        JButton btnRecarregar = botao("↻ Recarregar Histórico", new Color(60, 130, 160));
        btnRecarregar.setPreferredSize(new Dimension(200, 30));
        JPanel pRodape = new JPanel(new FlowLayout(FlowLayout.LEFT));
        pRodape.setBackground(Color.WHITE);
        pRodape.add(btnRecarregar);
        painel.add(pRodape, BorderLayout.NORTH);

        Runnable recarregar = () -> {
            modeloMov.setRowCount(0);
            new controller.MovimentacaoController().listarTodas().forEach(m -> {
                modeloMov.addRow(new Object[]{
                    m.getId(), m.getProdutoNome(), m.getTipo().name(),
                    m.getQuantidade(), m.getUsuarioLogin(),
                    m.getObservacao() != null ? m.getObservacao() : "",
                    m.getData()
                });
            });
        };

        btnRecarregar.addActionListener(e -> recarregar.run());
        recarregar.run();

        return painel;
    }

    // ==========================================================
    // Métodos auxiliares da aba Produtos
    // ==========================================================
    private void carregarProdutos() {
        modeloTabela.setRowCount(0);
        List<Produto> lista = ctrlProduto.listar();
        for (Produto p : lista) {
            modeloTabela.addRow(new Object[]{
                p.getId(),
                p.getNome(),
                p.getCategoriaNome(),
                p.getQuantidade(),
                String.format("R$ %.2f", p.getPreco()),
                p.getUsuarioLogin(),
                p.getCriadoEm() != null ? p.getCriadoEm().toString().substring(0, 16) : ""
            });
        }
    }

    private void buscarProdutos() {
        String termo = txtBusca.getText().trim();
        modeloTabela.setRowCount(0);
        List<Produto> lista = ctrlProduto.buscar(termo);
        for (Produto p : lista) {
            modeloTabela.addRow(new Object[]{
                p.getId(),
                p.getNome(),
                p.getCategoriaNome(),
                p.getQuantidade(),
                String.format("R$ %.2f", p.getPreco()),
                p.getUsuarioLogin(),
                p.getCriadoEm() != null ? p.getCriadoEm().toString().substring(0, 16) : ""
            });
        }
    }

    private void abrirCadastro() {
        TelaCadastroProduto tela = new TelaCadastroProduto(this);
        tela.setVisible(true);
        if (tela.isSalvo()) carregarProdutos();
    }

    private void abrirEdicao() {
        int linha = tabela.getSelectedRow();
        if (linha < 0) {
            JOptionPane.showMessageDialog(this, "Selecione um produto para editar.", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int id = (int) modeloTabela.getValueAt(linha, 0);
        Produto p = ctrlProduto.buscarPorId(id);
        if (p == null) { carregarProdutos(); return; }

        TelaCadastroProduto tela = new TelaCadastroProduto(this, p);
        tela.setVisible(true);
        if (tela.isSalvo()) carregarProdutos();
    }

    private void removerProduto() {
        int linha = tabela.getSelectedRow();
        if (linha < 0) {
            JOptionPane.showMessageDialog(this, "Selecione um produto para remover.", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String nome = (String) modeloTabela.getValueAt(linha, 1);
        int resp = JOptionPane.showConfirmDialog(this,
            "Deseja remover o produto \"" + nome + "\"?\nEssa ação não pode ser desfeita.",
            "Confirmar Remoção", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

        if (resp == JOptionPane.YES_OPTION) {
            int id = (int) modeloTabela.getValueAt(linha, 0);
            if (ctrlProduto.remover(id)) {
                JOptionPane.showMessageDialog(this, "Produto removido com sucesso.");
                carregarProdutos();
            } else {
                JOptionPane.showMessageDialog(this,
                    "Não foi possível remover. O produto pode ter movimentações vinculadas.",
                    "Erro", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void abrirMovimentacao() {
        int linha = tabela.getSelectedRow();
        if (linha < 0) {
            JOptionPane.showMessageDialog(this, "Selecione um produto para registrar movimentação.", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int id = (int) modeloTabela.getValueAt(linha, 0);
        Produto p = ctrlProduto.buscarPorId(id);
        if (p == null) { carregarProdutos(); return; }

        TelaMovimentacao tela = new TelaMovimentacao(this, p);
        tela.setVisible(true);
        carregarProdutos(); // atualiza quantidade após movimentação
    }

    // --- Fábrica de botões estilizados ---
    private JButton botao(String texto, Color cor) {
        JButton btn = new JButton(texto);
        btn.setBackground(cor);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("SansSerif", Font.BOLD, 12));
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setOpaque(true);
        return btn;
    }
}