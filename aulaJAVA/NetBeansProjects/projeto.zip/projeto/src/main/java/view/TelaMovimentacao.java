package view;

import controller.MovimentacaoController;
import model.Movimentacao;
import model.Produto;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class TelaMovimentacao extends JDialog {

    private JComboBox<String> cbTipo;
    private JTextField txtQuantidade;
    private JTextField txtObservacao;
    private JTable tabela;
    private DefaultTableModel modeloTabela;

    private final MovimentacaoController ctrl = new MovimentacaoController();
    private final Produto produto;

    public TelaMovimentacao(Frame pai, Produto produto) {
        super(pai, "Movimentações — " + produto.getNome(), true);
        this.produto = produto;
        setSize(620, 480);
        setLocationRelativeTo(pai);
        setResizable(false);
        construirUI();
        carregarHistorico();
    }

    private void construirUI() {
        setLayout(new BorderLayout(8, 8));
        getContentPane().setBackground(Color.WHITE);

        // ---- Painel de registro ----
        JPanel pForm = new JPanel(new GridBagLayout());
        pForm.setBorder(BorderFactory.createTitledBorder("Registrar Movimentação"));
        pForm.setBackground(Color.WHITE);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 6, 5, 6);

        gbc.gridy = 0; gbc.gridx = 0; gbc.weightx = 0.25;
        pForm.add(new JLabel("Produto:"), gbc);
        JLabel lblProduto = new JLabel(produto.getNome() + "  (estoque: " + produto.getQuantidade() + ")");
        lblProduto.setFont(new Font("SansSerif", Font.BOLD, 13));
        gbc.gridx = 1; gbc.gridwidth = 3; gbc.weightx = 0.75;
        pForm.add(lblProduto, gbc);

        gbc.gridwidth = 1;
        gbc.gridy = 1; gbc.gridx = 0; gbc.weightx = 0.25;
        pForm.add(new JLabel("Tipo:"), gbc);
        cbTipo = new JComboBox<>(new String[]{"ENTRADA", "SAIDA"});
        gbc.gridx = 1; gbc.weightx = 0.25;
        pForm.add(cbTipo, gbc);

        gbc.gridx = 2; gbc.weightx = 0.2;
        pForm.add(new JLabel("Quantidade:"), gbc);
        txtQuantidade = new JTextField(8);
        gbc.gridx = 3; gbc.weightx = 0.3;
        pForm.add(txtQuantidade, gbc);

        gbc.gridy = 2; gbc.gridx = 0; gbc.weightx = 0.25;
        pForm.add(new JLabel("Observação:"), gbc);
        txtObservacao = new JTextField(30);
        gbc.gridx = 1; gbc.gridwidth = 3; gbc.weightx = 0.75;
        pForm.add(txtObservacao, gbc);

        JButton btnRegistrar = new JButton("Registrar Movimentação");
        btnRegistrar.setBackground(new Color(21, 67, 135));
        btnRegistrar.setForeground(Color.WHITE);
        btnRegistrar.setFont(new Font("SansSerif", Font.BOLD, 13));
        btnRegistrar.setFocusPainted(false);
        btnRegistrar.setBorderPainted(false);
        btnRegistrar.setOpaque(true);
        btnRegistrar.setPreferredSize(new Dimension(220, 34));
        JPanel pBtnReg = new JPanel(new FlowLayout(FlowLayout.CENTER));
        pBtnReg.setBackground(Color.WHITE);
        pBtnReg.add(btnRegistrar);
        gbc.gridy = 3; gbc.gridx = 0; gbc.gridwidth = 4;
        pForm.add(pBtnReg, gbc);

        add(pForm, BorderLayout.NORTH);

        // ---- Tabela de histórico ----
        String[] colunas = {"ID", "Tipo", "Quantidade", "Usuário", "Observação", "Data"};
        modeloTabela = new DefaultTableModel(colunas, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        tabela = new JTable(modeloTabela);
        tabela.setRowHeight(24);
        tabela.setFont(new Font("SansSerif", Font.PLAIN, 12));
        tabela.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 12));
        tabela.getColumnModel().getColumn(0).setPreferredWidth(40);
        tabela.getColumnModel().getColumn(1).setPreferredWidth(70);
        tabela.getColumnModel().getColumn(2).setPreferredWidth(80);
        tabela.getColumnModel().getColumn(3).setPreferredWidth(90);
        tabela.getColumnModel().getColumn(4).setPreferredWidth(220);
        tabela.getColumnModel().getColumn(5).setPreferredWidth(130);

        JScrollPane scroll = new JScrollPane(tabela);
        scroll.setBorder(BorderFactory.createTitledBorder("Histórico de Movimentações"));
        add(scroll, BorderLayout.CENTER);

        // ---- Botão fechar ----
        JButton btnFechar = new JButton("Fechar");
        btnFechar.setBackground(new Color(100, 100, 100));
        btnFechar.setForeground(Color.WHITE);
        btnFechar.setFont(new Font("SansSerif", Font.BOLD, 13));
        btnFechar.setFocusPainted(false);
        btnFechar.setBorderPainted(false);
        btnFechar.setOpaque(true);
        btnFechar.setPreferredSize(new Dimension(110, 34));
        JPanel pRodape = new JPanel(new FlowLayout(FlowLayout.CENTER));
        pRodape.setBackground(Color.WHITE);
        pRodape.setBorder(new EmptyBorder(0, 8, 8, 8));
        pRodape.add(btnFechar);
        add(pRodape, BorderLayout.SOUTH);

        // --- Ações ---
        btnRegistrar.addActionListener(e -> registrar());
        btnFechar.addActionListener(e -> dispose());
    }

    private void registrar() {
        String tipo = (String) cbTipo.getSelectedItem();
        try {
            boolean ok = ctrl.registrar(produto.getId(), tipo, txtQuantidade.getText(), txtObservacao.getText());
            if (ok) {
                JOptionPane.showMessageDialog(this, "Movimentação registrada com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                txtQuantidade.setText("");
                txtObservacao.setText("");
                carregarHistorico();
            } else {
                JOptionPane.showMessageDialog(this,
                    "Erro ao registrar. Verifique se há estoque suficiente para saída.",
                    "Erro", JOptionPane.ERROR_MESSAGE);
            }
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Validação", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void carregarHistorico() {
        modeloTabela.setRowCount(0);
        List<Movimentacao> lista = ctrl.listarPorProduto(produto.getId());
        for (Movimentacao m : lista) {
            modeloTabela.addRow(new Object[]{
                m.getId(),
                m.getTipo().name(),
                m.getQuantidade(),
                m.getUsuarioLogin(),
                m.getObservacao() != null ? m.getObservacao() : "",
                m.getData()
            });
        }
    }
}