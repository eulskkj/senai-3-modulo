package view;

import controller.UsuarioController;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class TelaCadastroUsuario extends JFrame {

    private JTextField txtLogin;
    private JPasswordField txtSenha;
    private JPasswordField txtConfirma;
    private final UsuarioController ctrl = new UsuarioController();
    private final JFrame telaPai;

    public TelaCadastroUsuario(JFrame telaPai) {
        this.telaPai = telaPai;
        setTitle("Cadastro de Usuário");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(420, 320);
        setLocationRelativeTo(null);
        setResizable(false);
        construirUI();

        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosed(java.awt.event.WindowEvent e) {
                telaPai.setVisible(true);
            }
        });
    }

    private void construirUI() {
        JPanel painel = new JPanel(new GridBagLayout());
        painel.setBorder(new EmptyBorder(24, 32, 24, 32));
        painel.setBackground(Color.WHITE);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(7, 4, 7, 4);

        // Título
        JLabel titulo = new JLabel("Criar Nova Conta", SwingConstants.CENTER);
        titulo.setFont(new Font("SansSerif", Font.BOLD, 18));
        titulo.setForeground(new Color(33, 89, 160));
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        painel.add(titulo, gbc);

        gbc.gridwidth = 1;

        // Login
        gbc.gridy = 1; gbc.gridx = 0; gbc.weightx = 0.35;
        painel.add(new JLabel("Login:"), gbc);
        txtLogin = new JTextField(16);
        gbc.gridx = 1; gbc.weightx = 0.65;
        painel.add(txtLogin, gbc);

        // Senha
        gbc.gridy = 2; gbc.gridx = 0; gbc.weightx = 0.35;
        painel.add(new JLabel("Senha:"), gbc);
        txtSenha = new JPasswordField(16);
        gbc.gridx = 1; gbc.weightx = 0.65;
        painel.add(txtSenha, gbc);

        // Confirmar senha
        gbc.gridy = 3; gbc.gridx = 0; gbc.weightx = 0.35;
        painel.add(new JLabel("Confirmar Senha:"), gbc);
        txtConfirma = new JPasswordField(16);
        gbc.gridx = 1; gbc.weightx = 0.65;
        painel.add(txtConfirma, gbc);

        // Aviso de senha mínima
        JLabel lblAviso = new JLabel("* Senha mínima de 4 caracteres");
        lblAviso.setFont(new Font("SansSerif", Font.ITALIC, 11));
        lblAviso.setForeground(Color.GRAY);
        gbc.gridy = 4; gbc.gridx = 0; gbc.gridwidth = 2;
        painel.add(lblAviso, gbc);

        // Painel de botões
        JPanel pBotoes = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 0));
        pBotoes.setBackground(Color.WHITE);

        JButton btnCadastrar = new JButton("Cadastrar");
        btnCadastrar.setBackground(new Color(22, 110, 60));
        btnCadastrar.setForeground(Color.WHITE);
        btnCadastrar.setFont(new Font("SansSerif", Font.BOLD, 13));
        btnCadastrar.setFocusPainted(false);
        btnCadastrar.setBorderPainted(false);
        btnCadastrar.setOpaque(true);
        btnCadastrar.setPreferredSize(new Dimension(120, 32));

        JButton btnVoltar = new JButton("Voltar");
        btnVoltar.setBackground(new Color(100, 100, 100));
        btnVoltar.setForeground(Color.WHITE);
        btnVoltar.setFont(new Font("SansSerif", Font.BOLD, 13));
        btnVoltar.setFocusPainted(false);
        btnVoltar.setBorderPainted(false);
        btnVoltar.setOpaque(true);
        btnVoltar.setPreferredSize(new Dimension(100, 32));

        pBotoes.add(btnVoltar);
        pBotoes.add(btnCadastrar);

        gbc.gridy = 5; gbc.gridwidth = 2;
        painel.add(pBotoes, gbc);

        add(painel);

        // --- Ações ---
        btnCadastrar.addActionListener(e -> cadastrar());
        txtConfirma.addActionListener(e -> cadastrar());

        btnVoltar.addActionListener(e -> {
            dispose();
        });
    }

    private void cadastrar() {
        String login    = txtLogin.getText().trim();
        String senha    = new String(txtSenha.getPassword());
        String confirma = new String(txtConfirma.getPassword());

        if (login.isEmpty()) {
            erro("O campo login é obrigatório.");
            txtLogin.requestFocus();
            return;
        }
        if (senha.length() < 4) {
            erro("A senha deve ter pelo menos 4 caracteres.");
            txtSenha.requestFocus();
            return;
        }
        if (!senha.equals(confirma)) {
            erro("As senhas não coincidem.");
            txtConfirma.setText("");
            txtConfirma.requestFocus();
            return;
        }

        boolean ok = ctrl.cadastrar(login, senha, confirma);
        if (ok) {
            JOptionPane.showMessageDialog(this,
                "Usuário '" + login + "' cadastrado com sucesso!\nFaça login para continuar.",
                "Sucesso", JOptionPane.INFORMATION_MESSAGE);
            dispose();
        } else {
            erro("Login '" + login + "' já está em uso. Escolha outro.");
            txtLogin.requestFocus();
        }
    }

    private void erro(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Erro de Validação", JOptionPane.ERROR_MESSAGE);
    }
}