package view;

import controller.UsuarioController;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;

public class TelaLogin extends JFrame {

    private JTextField txtLogin;
    private JPasswordField txtSenha;
    private final UsuarioController ctrl = new UsuarioController();

    public TelaLogin() {
        setTitle("Sistema de Estoque — Login");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(400, 280);
        setLocationRelativeTo(null);
        setResizable(false);
        construirUI();
    }

    private void construirUI() {
        JPanel painel = new JPanel(new GridBagLayout());
        painel.setBorder(new EmptyBorder(24, 32, 24, 32));
        painel.setBackground(Color.WHITE);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(6, 4, 6, 4);

        // Título
        JLabel titulo = new JLabel("Controle de Estoque", SwingConstants.CENTER);
        titulo.setFont(new Font("SansSerif", Font.BOLD, 20));
        titulo.setForeground(new Color(33, 89, 160));
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        painel.add(titulo, gbc);

        gbc.gridwidth = 1;

        // Login
        gbc.gridy = 1; gbc.gridx = 0; gbc.weightx = 0.3;
        painel.add(new JLabel("Login:"), gbc);
        txtLogin = new JTextField(16);
        gbc.gridx = 1; gbc.weightx = 0.7;
        painel.add(txtLogin, gbc);

        // Senha
        gbc.gridy = 2; gbc.gridx = 0; gbc.weightx = 0.3;
        painel.add(new JLabel("Senha:"), gbc);
        txtSenha = new JPasswordField(16);
        gbc.gridx = 1; gbc.weightx = 0.7;
        painel.add(txtSenha, gbc);

        // Botão Entrar
        JButton btnEntrar = new JButton("Entrar");
        btnEntrar.setBackground(new Color(21, 67, 135));
        btnEntrar.setForeground(Color.WHITE);
        btnEntrar.setFont(new Font("SansSerif", Font.BOLD, 13));
        btnEntrar.setFocusPainted(false);
        btnEntrar.setOpaque(true);
        btnEntrar.setBorderPainted(false);
        gbc.gridy = 3; gbc.gridx = 0; gbc.gridwidth = 2;
        painel.add(btnEntrar, gbc);

        // Link cadastro
        JButton btnCadastro = new JButton("Não tem conta? Cadastre-se");
        btnCadastro.setBorderPainted(false);
        btnCadastro.setContentAreaFilled(false);
        btnCadastro.setForeground(new Color(33, 89, 160));
        btnCadastro.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        gbc.gridy = 4;
        painel.add(btnCadastro, gbc);

        add(painel);

        // --- Ações ---
        ActionListener acaoLogin = e -> fazerLogin();
        btnEntrar.addActionListener(acaoLogin);
        txtSenha.addActionListener(acaoLogin);  // Enter na senha aciona login

        btnCadastro.addActionListener(e -> {
            new TelaCadastroUsuario(this).setVisible(true);
            setVisible(false);
        });
    }

    private void fazerLogin() {
        String login = txtLogin.getText().trim();
        String senha = new String(txtSenha.getPassword());

        if (login.isEmpty() || senha.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Preencha login e senha.", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (ctrl.login(login, senha)) {
            new TelaPrincipal().setVisible(true);
            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Login ou senha incorretos.", "Erro", JOptionPane.ERROR_MESSAGE);
            txtSenha.setText("");
            txtSenha.requestFocus();
        }
    }
}